import React, { useCallback, useEffect, useRef, useState } from 'react';
import { COLORS } from '../data/initialData';
import { downloadStudentReport, downloadSectionStudentsReport } from '../utils/pdfReports';
import { buildUrl } from '../utils/apiConfig';
import Tooltip from '../erp/shared/Tooltip';
import { useSetupTabPerms } from '../utils/setupPermissions';
import SetupLoader from '../components/SetupLoader';
import quickTemplate from '../BulkStudents_Quick.xlsx';
import detailedTemplate from '../BulkStudents_Detailed_Template.xlsx';

// ── Add/Edit Student Modal ────────────────────────────────────────────────────
const EMPTY_STUDENT = {
  // Registration / names
  registrationNo: '', familyNo: '', dateOfAdmission: '', name: '', lastName: '',
  firstNameUrdu: '', lastNameUrdu: '', fatherNameUrdu: '',
  fatherName: '', fatherCnic: '', fatherQualification: '', fatherOccupation: '',
  motherName: '', motherCnic: '', motherQualification: '', motherOccupation: '',
  gender: '', dob: '', caste: '', nationality: '',
  postalAddress: '', permanentAddress: '', mobile: '', motherMobile: '',
  email: '', bFormNo: '', marksPercent: '', dues: '0', profilePhoto: '',
  regNo: '', cnic: '', previousRegistrationNo: '',
  // Previous institutional history
  prevSchoolName: '', focalPerson: '', prevContactNo: '', prevSchoolAddress: '',
  admissionNo: '', previousGrade: '', testOfGrade: '',
  // Health & emergency
  bloodGroup: '', foodDietary: '', allergies: '', conditionOfChild: '', emergencyContact: '',
};

function StudentModal({ open, target, editIdx, editStudent, classesData, onClose, onSaved, showToast, manualReg }) {
  const [formType, setFormType] = useState('quick');
  const [openSec, setOpenSec] = useState({ reg: true, history: true, health: true });
  const [form, setForm] = useState(EMPTY_STUDENT);
  const [errors, setErrors] = useState({});

  const row = target ? classesData.flatMap(cls => {
    const secs = cls.sections?.length ? cls.sections : [null];
    return secs.map(sec => ({ cls, sec, key: `${cls.id}_${sec?.sectionID ?? 'null'}` }));
  }).find(r => r.key === target) : null;

  React.useEffect(() => {
    if (open) {
      setErrors({});
      setOpenSec({ reg: true, history: true, health: true });
      if (editStudent) {
        // map API student → modal form keys
        setFormType('detail');
        setForm({
          ...EMPTY_STUDENT,
          ...editStudent,
          registrationNo: editStudent.registerNo ?? editStudent.registrationNo ?? '',
          familyNo:       editStudent.familyNo ?? '',
          dateOfAdmission: editStudent.dateOfAdmission && editStudent.dateOfAdmission !== 'string' ? editStudent.dateOfAdmission : '',
          name:           editStudent.firstName ?? editStudent.name ?? '',
          lastName:       editStudent.lastName ?? '',
          firstNameUrdu:  editStudent.firstNameInUrdu ?? '',
          lastNameUrdu:   editStudent.lastNameInUrdu ?? '',
          fatherName:     editStudent.fatherName ?? '',
          fatherCnic:     editStudent.fatherCnic ?? '',
          fatherQualification: editStudent.fatherQualification ?? '',
          fatherOccupation:    editStudent.fatherOccupation ?? '',
          motherName:     editStudent.motherName ?? '',
          motherCnic:     editStudent.motherCnic ?? '',
          motherQualification: editStudent.motherQualification ?? '',
          motherOccupation:    editStudent.motherOccupation ?? '',
          gender:         editStudent.gander ?? editStudent.gender ?? '',
          dob:            editStudent.dateOfBirth && editStudent.dateOfBirth !== 'string' ? String(editStudent.dateOfBirth).split('T')[0] : '',
          caste:          editStudent.caste ?? '',
          nationality:    editStudent.nationality ?? '',
          postalAddress:  editStudent.postalAddress ?? '',
          mobile:         editStudent.mobileNo ?? editStudent.mobile ?? '',
          motherMobile:   editStudent.motherMobileNo ?? '',
          email:          editStudent.email ?? '',
          bFormNo:        editStudent.bFormNo ?? '',
          marksPercent:   editStudent.marksAdmissionTest ?? '',
          dues:           String(editStudent.totalPreviousDues ?? editStudent.dues ?? 0),
          profilePhoto:   editStudent.picture && editStudent.picture !== 'string' ? editStudent.picture : '',
          prevSchoolName: editStudent.previousSchoolName ?? '',
          focalPerson:    editStudent.previousSchoolFocalPerson ?? '',
          prevContactNo:  editStudent.previousSchoolContactNo ?? '',
          prevSchoolAddress: editStudent.previousSchoolAddress ?? '',
          admissionNo:    editStudent.previousAdmissionNo ?? '',
          previousGrade:  editStudent.previousSchoolPreviousGrade ?? '',
          testOfGrade:    editStudent.previousSchoolTestOfGrades ?? '',
          bloodGroup:     editStudent.bloodGroup ?? '',
          foodDietary:    editStudent.foodAndDietaryReg ?? '',
          allergies:      editStudent.allergiesMajorIllness ?? '',
          conditionOfChild: editStudent.conditionOfChild ?? '',
          emergencyContact: editStudent.emergencyContact ?? '',
          previousRegistrationNo: editStudent.previousRegistrationNo ?? '',
          permanentAddress:       editStudent.permanentAddesss ?? editStudent.permanentAddress ?? '',
        });
      } else {
        setFormType('quick');
        setForm(EMPTY_STUDENT);
      }
    }
  }, [open, target, editStudent]);

  const set = (k, v) => { setForm(p => ({ ...p, [k]: v })); setErrors(p => ({ ...p, [k]: '' })); };

  const handleImage = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setForm(prev => ({ ...prev, pictureFile: file }));
    const reader = new FileReader();
    reader.onload = () => set('profilePhoto', reader.result);
    reader.readAsDataURL(file);
  };

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Student name is required';
    if (!form.fatherName.trim()) e.fatherName = 'Father name is required';
    if (!form.mobile.trim()) e.mobile = 'Contact number is required';
    if (formType === 'quick') {
      if (!form.dob) e.dob = 'Date of birth is required';
      if (!form.gender) e.gender = 'Gender is required';
    } else if (!form.registrationNo.trim()) {
      e.registrationNo = 'Registration No is required';
    }
    if (form.dob && form.dob > new Date().toISOString().slice(0, 10)) e.dob = 'Date of birth cannot be in the future';
    if (form.dues === '' || isNaN(Number(form.dues)) || Number(form.dues) < 0) e.dues = 'Enter dues (0 if none)';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;
    const now = new Date().toISOString();
    const userID = Number(sessionStorage.getItem('UserID')) || 0;
    const fd = new FormData();
    fd.append('ID',                          editStudent?.id ?? form.id ?? 0);
    fd.append('GradeId',                     row.cls.id);
    fd.append('SectionId',                   row.sec?.sectionID ?? 0);
    fd.append('BranchId',                    Number(sessionStorage.getItem('branchID')) || 0);
    fd.append('RegisterNo',                  form.registrationNo || form.regNo || '');
    /* Manual mode flag — is ke baghair backend RegisterNo ko ignore kar ke apna
       system-generated number laga deta tha. ON hone par backend user ka diya hua
       RegisterNo use karta hai (save-school ki tarah, dekho SchoolTab IsManualRegNo). */
    fd.append('IsManualRegNo',               !!manualReg);
    fd.append('PreviousRegistrationNo',      form.previousRegistrationNo || '');
    fd.append('FamilyNo',                    form.familyNo || '');
    fd.append('DateOfAdmission',             form.dateOfAdmission || '');
    fd.append('FirstName',                   form.name || '');
    fd.append('LastName',                    form.lastName || '');
    fd.append('FirstNameInUrdu',             form.firstNameUrdu || '');
    fd.append('LastNameInUrdu',              form.lastNameUrdu || '');
    fd.append('FatherName',                  form.fatherName || '');
    fd.append('FatherCnic',                  form.fatherCnic || '');
    fd.append('FatherQualification',         form.fatherQualification || '');
    fd.append('FatherOccupation',            form.fatherOccupation || '');
    fd.append('MotherName',                  form.motherName || '');
    fd.append('MotherCnic',                  form.motherCnic || '');
    fd.append('MotherQualification',         form.motherQualification || '');
    fd.append('MotherOccupation',            form.motherOccupation || '');
    fd.append('Gander',                      form.gender || '');
    fd.append('DateOfBirth',                 form.dob || '');
    fd.append('Caste',                       form.caste || '');
    fd.append('Nationality',                 form.nationality || '');
    fd.append('PostalAddress',               form.postalAddress || '');
    fd.append('PermanentAddesss',            form.permanentAddress || '');
    fd.append('MobileNo',                    form.mobile || '');
    fd.append('MotherMobileNo',              form.motherMobile || '');
    fd.append('Email',                       form.email || '');
    fd.append('BFormNo',                     form.bFormNo || '');
    fd.append('MarksAdmissionTest',          form.marksPercent || '');
    fd.append('TotalPreviousDues',           Number(form.dues) || 0);
    fd.append('Picture',                     "");
    fd.append('PreviousSchoolName',          form.prevSchoolName || '');
    fd.append('PreviousSchoolFocalPerson',   form.focalPerson || '');
    fd.append('PreviousSchoolContactNo',     form.prevContactNo || '');
    fd.append('PreviousSchoolAddress',       form.prevSchoolAddress || '');
    fd.append('PreviousAdmissionNo',         form.admissionNo || '');
    fd.append('PreviousSchoolPreviousGrade', form.previousGrade || '');
    fd.append('PreviousSchoolTestOfGrades',  form.testOfGrade || '');
    fd.append('BloodGroup',                  form.bloodGroup || '');
    fd.append('FoodAndDietaryReg',           form.foodDietary || '');
    fd.append('AllergiesMajorIllness',       form.allergies || '');
    fd.append('ConditionOfChild',            form.conditionOfChild || '');
    fd.append('EmergencyContact',            form.emergencyContact || '');
    fd.append('CreatedAt',                   now);
    fd.append('CreatedBy',                   userID);
    fd.append('ModifiedAt',                  now);
    fd.append('ModifiedBy',                  userID);
    fd.append('IsActive',                    true);
    if (form.pictureFile) fd.append('PictureFile', form.pictureFile);
    try {
      const res  = await fetch(buildUrl('/api/LaunchSetup/save-student'), {
        method: 'POST',
        headers: { Accept: '*/*' },
        body: fd,
      });
      const data = await res.json();
      /* API HTTP 200 + top-level "…saved successfully" deta hai, magar ASLI natija
         `data` mein hota hai. Duplicate (e.g. reg/mobile) par shapes:
            data: 0  |  data: [{ Success: 0, Message: "Number already exist" }]  |  data: { Success: 0, Message }
         In sab ko fail treat karo aur exact error toast dikhao (na "added"). */
      const d = data?.data;
      const inner = Array.isArray(d) ? d[0] : (d && typeof d === 'object' ? d : null);
      const innerSuccess = inner ? (inner.Success ?? inner.success) : undefined;
      // const isFail = innerSuccess === 0 || innerSuccess === false || innerSuccess === '0' || d === 0 || d === '0';
     
     const isFail =
  data?.success === false ||
  data?.success === 0 ||
  data?.Success === false ||
  data?.Success === 0 ||
  innerSuccess === 0 ||
  innerSuccess === false ||
  innerSuccess === '0' ||
  d === 0 ||
  d === '0';
      if (res.ok && !isFail) {
        showToast?.(editStudent ? 'Student updated successfully' : 'Student added successfully', 'success');
        onSaved?.();   // refetch class/section/student list
        onClose();
      } else {
 const msg =
  data?.message ||
  data?.Message ||
  (inner && (inner.Message ?? inner.message)) ||
  'Number already exists';
        showToast?.(msg, 'error');
      }
    } catch (err) {
      console.error(err);
      showToast?.('Network error. Please try again.', 'error');
    }
  };

  if (!open || !row) return null;

  // ── field helpers (plain functions so inputs don't lose focus on re-render) ──
  const field = (label, node, { req, id, span } = {}) => (
    <div className="form-group" style={span ? { gridColumn: `span ${span}` } : undefined}>
      <label className="form-label">{label} {req && <span className="req-star">*</span>}</label>
      {node}
      {id && errors[id] && <span className="field-msg error"><i className="fas fa-times-circle"></i> {errors[id]}</span>}
    </div>
  );
  const todayStr = new Date().toISOString().slice(0, 10);
  const inp = (key, ph, type = 'text') => (
    <input
      className={`form-input${errors[key] ? ' error-field' : ''}`}
      type={type}
      placeholder={ph}
      value={form[key]}
      max={type === 'date' && key === 'dob' ? todayStr : undefined}
      onChange={e => set(key, e.target.value)}
    />
  );
  const sel = (key, placeholder, options) => (
    <select className={`form-select${errors[key] ? ' error-field' : ''}`} value={form[key]} onChange={e => set(key, e.target.value)}>
      <option value="">{placeholder}</option>
      {options.map(o => <option key={o}>{o}</option>)}
    </select>
  );
  const grid = (cols, children) => (
    <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 16 }}>{children}</div>
  );
  const section = (key, icon, title, children) => (
    <div style={{ border: '1px solid #cdddf5', borderRadius: 12, marginBottom: 16, overflow: 'hidden' }}>
      <div
        onClick={() => setOpenSec(s => ({ ...s, [key]: !s[key] }))}
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 18px', background: '#dbe7fb', cursor: 'pointer' }}
      >
        <span style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 14, fontWeight: 700, color: 'var(--brand-primary)' }}>
          <i className={`fas ${icon}`}></i> {title}
        </span>
        <i className={`fas fa-chevron-${openSec[key] ? 'up' : 'down'}`} style={{ color: 'var(--brand-primary)', fontSize: 14 }}></i>
      </div>
      {openSec[key] && <div style={{ padding: 18 }}>{children}</div>}
    </div>
  );

  const GENDER = ['Male', 'Female', 'Other'];
  const NATIONALITY = ['Pakistani', 'Other'];
  const BLOOD = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

  return (
    <div className="modal-overlay open" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal modal-xl" style={{ maxHeight: '90vh', display: 'flex', flexDirection: 'column' }}>
        {/* Header */}
        <div className="modal-header">
          <div>
            <div className="modal-title">{editIdx >= 0 ? 'Update Student' : 'Add Student'}</div>
            <div className="modal-subtitle">Choose form type below</div>
            <span style={{ display: 'inline-block', marginTop: 8, background: 'rgba(30,58,138,.08)', border: '1px solid rgba(30,58,138,.15)', color: 'var(--brand-primary)', fontSize: 12, fontWeight: 700, padding: '4px 12px', borderRadius: 99 }}>
              {row.cls.name}{row.sec ? ` · ${row.sec.sectionName}` : ''}
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
            <div style={{ display: 'flex', gap: 4, background: 'var(--bg-muted)', borderRadius: 10, padding: 4 }}>
              {[['quick', 'Quick Form', 'fa-bolt'], ['detail', 'Detailed Form', 'fa-list']].map(([type, lbl, icon]) => (
                <button key={type} onClick={() => setFormType(type)}
                  style={{ padding: '8px 16px', fontSize: 12.5, fontWeight: 700, border: 'none', cursor: 'pointer', fontFamily: 'var(--font-body)', display: 'inline-flex', alignItems: 'center', gap: 6, borderRadius: 8,
                    background: formType === type ? 'var(--brand-primary)' : 'transparent',
                    color: formType === type ? '#fff' : 'var(--text-secondary)',
                    boxShadow: formType === type ? '0 2px 8px rgba(30,58,138,.28)' : 'none' }}>
                  <i className={`fas ${icon}`}></i> {lbl}
                </button>
              ))}
            </div>
            <button className="modal-close" onClick={onClose}><i className="fas fa-times"></i></button>
          </div>
        </div>

        <div className="modal-body" style={{ overflowY: 'auto', flex: 1 }}>
          {formType === 'quick' ? (
            <div>
              <div style={{ textAlign: 'center', fontSize: 17, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 22 }}>
                Add Student in Class <span style={{ color: 'var(--brand-primary)' }}>{row.cls.name}</span>{row.sec ? <> in <span style={{ color: 'var(--brand-primary)' }}>{row.sec.sectionName}</span></> : ''}
              </div>
              {grid(3, <>
                {field('Student First Name', inp('name', 'First Name'), { req: true, id: 'name' })}
                {field('Last Name', inp('lastName', 'Last Name'))}
                {field('Father Name', inp('fatherName', 'Father Name'), { req: true, id: 'fatherName' })}
                {field('Date of Birth', inp('dob', '', 'date'), { req: true, id: 'dob' })}
                {field('Gender', sel('gender', 'Select Gender', GENDER), { req: true, id: 'gender' })}
                {field('Previous Registration #', inp('previousRegistrationNo', 'Please Enter Previous Reg'))}
                {field('Contact No', inp('mobile', 'Contact number'), { req: true, id: 'mobile' })}
                {field('Email', inp('email', 'student@email.com', 'email'))}
                {field('Total Previous Dues', inp('dues', '0', 'number'), { req: true, id: 'dues' })}
              </>)}
            </div>
          ) : (
            <div>
              {/* Student Registration Form */}
              {section('reg', 'fa-user', 'Student Registration Form', grid(4, <>
                {field('Registration No', inp('registrationNo', '245-42343'), { req: true, id: 'registrationNo' })}
                {field('Previous Registration No', inp('previousRegistrationNo', 'Enter Here'))}
                {field('Family No', inp('familyNo', 'Enter Here'))}
                {field('Date of Admission', inp('dateOfAdmission', '', 'date'))}
                {field('First Name', inp('name', 'Enter Here'), { req: true, id: 'name' })}
                {field('Last Name', inp('lastName', 'Enter Here'))}
                {field('First Name In Urdu', inp('firstNameUrdu', 'Enter Here'))}
                {field('Last Name In Urdu', inp('lastNameUrdu', 'Enter Here'))}
                {field('Father Name In Urdu', inp('fatherNameUrdu', 'Enter Here'))}
                {field('Father Name', inp('fatherName', 'Enter Here'), { req: true, id: 'fatherName' })}
                {field('Father CNIC', inp('fatherCnic', '_____/_______/_'))}
                {field("Father's Qualification", inp('fatherQualification', 'Enter Here'))}
                {field("Father's Occupation", inp('fatherOccupation', 'Enter Here'))}
                {field('Mother Name', inp('motherName', 'Enter Here'))}
                {field('Mother CNIC', inp('motherCnic', '_____/_______/_'))}
                {field("Mother's Qualification", inp('motherQualification', 'Enter Here'))}
                {field("Mother's Occupation", inp('motherOccupation', 'Enter Here'))}
                {field('Gender', sel('gender', 'Select Gender', GENDER))}
                {field('Date of Birth', inp('dob', '', 'date'))}
                {field('Caste', inp('caste', 'Enter Here'))}
                {field('Nationality', sel('nationality', 'Select Nationality', NATIONALITY))}
                {field('Postal Address', inp('postalAddress', 'Enter Here'))}
                {field('Permanent Address', inp('permanentAddress', 'Enter Here'))}
                {field('Mobile No', inp('mobile', '+92 348 120000'), { req: true, id: 'mobile' })}
                {field('Mother Mobile No', inp('motherMobile', '+92 348 120000'))}
                {field('Email', inp('email', 'student@gmail.com', 'email'))}
                {field('B-Form No (optional)', inp('bFormNo', '132465'))}
                {field('Marks % (Admission Test)', inp('marksPercent', '132465'))}
                {field('Total Previous Dues', inp('dues', '0', 'number'), { req: true, id: 'dues' })}
                {field('Profile Photo', (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <div style={{ width: 70, height: 70, borderRadius: 10, border: '1px dashed var(--border-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', background: 'var(--bg-muted)', fontSize: 11, color: 'var(--text-muted)', flexShrink: 0 }}>
                      {form.profilePhoto ? <img src={form.profilePhoto} alt="preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span><i className="fas fa-image"></i></span>}
                    </div>
                    <label className="btn btn-primary btn-sm" style={{ cursor: 'pointer' }}>
                      <i className="fas fa-folder-open"></i> Browse
                      <input type="file" accept="image/*" onChange={handleImage} style={{ display: 'none' }} />
                    </label>
                  </div>
                ), { span: 4 })}
              </>))}

              {/* Previous Institutional History */}
              {section('history', 'fa-clock-rotate-left', 'Previous Institutional History', grid(3, <>
                {field('School Name', inp('prevSchoolName', 'Enter Here'))}
                {field('Focal Person', inp('focalPerson', 'Enter Here'))}
                {field('Contact No', inp('prevContactNo', 'Enter Here'))}
                {field('School Address', inp('prevSchoolAddress', 'Enter Here'), { span: 3 })}
                {field('Admission No', inp('admissionNo', 'Enter Here'))}
                {field('Previous Grade', inp('previousGrade', 'Enter Here'))}
                {field('Test of Grade', inp('testOfGrade', 'Enter Here'))}
              </>))}

              {/* Health & Emergency Information */}
              {section('health', 'fa-heart-pulse', 'Health & Emergency Information', grid(4, <>
                {field('Blood Group', sel('bloodGroup', 'Select Blood group', BLOOD))}
                {field('Food and Dietary Req', inp('foodDietary', 'Enter Here'))}
                {field('Allergies/Major Illness', inp('allergies', 'Enter Here'))}
                {field('Condition of the Child', inp('conditionOfChild', 'Enter Here'))}
                {field('Emergency Contact', inp('emergencyContact', 'Enter Here'))}
              </>))}
            </div>
          )}
        </div>

        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', padding: '14px 24px', borderTop: '1px solid var(--border-light)', background: 'var(--bg-card)', borderRadius: '0 0 20px 20px', flexShrink: 0 }}>
          <button className="btn btn-secondary btn-md" onClick={onClose}>Close</button>
          <Tooltip text={editIdx >= 0 ? 'Save changes to this student' : 'Add a new student'}>
            <button className="btn btn-primary btn-md" onClick={handleSave}>
              <i className="fas fa-save"></i> Save Changes
            </button>
          </Tooltip>
        </div>
      </div>
    </div>
  );
}

// ── Main StudentTab ───────────────────────────────────────────────────────────
export default function StudentTab({ classesData, setClassesData, studentStrengths, setStudentStrengths, manualReg, 
  setManualReg, schoolInfo, showToast, showSuccess }) {
  /* Launch Setup ▸ Student Details ki permissions. */
  const { canCreate, canEdit, canDelete, canDownload, canImport } = useSetupTabPerms('student');
  /* Pehla fetch mukammal hone tak loader — koi placeholder row nahi. */
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [expandedKey, setExpandedKey] = useState(null);
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(8);   // rows per page — pagination dropdown
  const [students, setStudents] = useState({}); // { key: [student...] }
  const [showStudentModal, setShowStudentModal] = useState(false);
  const [stuTarget, setStuTarget] = useState(null);
  const [stuEditIdx, setStuEditIdx] = useState(-1);
  const [stuEditData, setStuEditData] = useState(null);
  const [deleteStuTarget, setDeleteStuTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [showImport, setShowImport] = useState(null);
  const [importStep, setImportStep] = useState(1);
        const branchID = sessionStorage.getItem('branchID');
  const [importType, setImportType] = useState('quick');
  const [importFile, setImportFile] = useState(null);       // selected .xlsx File
  const [importPreview, setImportPreview] = useState(null); // { headers, rows }
  const [importing, setImporting] = useState(false);
  const importInputRef = useRef(null);

  const STU_PER_PAGE = 8;   // default rows per page

  const buildRows = () => {
    const rows = [];
    classesData.forEach(cls => {
      const secs = cls.sections?.length ? cls.sections : [null];
      secs.forEach(sec => rows.push({ cls, sec }));
    });
    return rows;
  };

  const allRows = buildRows();
  const filtered = search
    ? allRows.filter(({ cls, sec }) =>
        cls.name.toLowerCase().includes(search.toLowerCase()) ||
        (sec?.sectionName && sec.sectionName.toLowerCase().includes(search.toLowerCase())))
    : allRows;

  const pages = Math.ceil(filtered.length / perPage) || 1;
  const currentPage = Math.min(page, pages);
  const paged = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);

  const getKey = (clsId, sec) => `${clsId}_${sec?.sectionID ?? 'null'}`;
  const normalizeStudent = (st) => ({
    ...st,
    regNo:      st.registerNo ?? st.regNo ?? '',
    name:       st.name ?? `${st.firstName ?? ''} ${st.lastName ?? ''}`.trim(),
    fatherName: st.fatherName ?? '',
    dob:        st.dateOfBirth ?? st.dob ?? '',
    mobile:     st.mobileNo ?? st.mobile ?? '',
    dues:       st.totalPreviousDues ?? st.dues ?? 0,
  });
  const getStudents = (clsId, sec) => {
    const apiList = (sec?.students || []).map(normalizeStudent);
    const localList = students[getKey(clsId, sec)] || [];
    return apiList.length ? apiList : localList;
  };
  const getStrength = (clsId, sec) => {
    const stuList = getStudents(clsId, sec);
    return stuList.length > 0 ? stuList.length : (studentStrengths[getKey(clsId, sec)] || 0);
  };

  const setStrength = (clsId, sec, val) => {
    setStudentStrengths(prev => ({ ...prev, [getKey(clsId, sec)]: Math.max(0, parseInt(val) || 0) }));
  };

  const handleSaveStudent = (key, student, editIdx) => {
    setStudents(prev => {
      const list = [...(prev[key] || [])];
      if (editIdx >= 0) list[editIdx] = student;
      else list.push(student);
      return { ...prev, [key]: list };
    });
    showSuccess(
      editIdx >= 0 ? 'Student Updated!' : 'Student Added!',
      `"${student.name}" has been ${editIdx >= 0 ? 'updated' : 'enrolled'}.`,
      `<strong>Father:</strong> ${student.fatherName}<br><strong>Mobile:</strong> ${student.mobile}`
    );
  };

  const confirmDeleteStudent = async () => {
    if (!deleteStuTarget?.id) { setDeleteStuTarget(null); return; }
    setDeleting(true);
    console.log(deleteStuTarget)
    try {
      const res = await fetch(buildUrl(`/api/LaunchSetup/delete-student-permanent/${deleteStuTarget.id}`), {
        method: 'DELETE',
        headers: { Accept: '*/*' },
      });
      if (res.ok) {
        showToast(`"${deleteStuTarget.firstName}" Deleted`, 'success');
        getclassesdata();
      } else {
        const data = await res.json().catch(() => ({}));
        showToast(data?.message || 'Delete failed', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Network error. Please try again.', 'error');
    } finally {
      setDeleting(false);
      setDeleteStuTarget(null);
    }
  };

  const openAddStudent = (key) => {
    setStuTarget(key); setStuEditIdx(-1); setStuEditData(null); setShowStudentModal(true);
  };
  const openEditStudent = (key, student, idx) => {
    setStuTarget(key); setStuEditIdx(idx); setStuEditData(student); setShowStudentModal(true);
  };

  /* Bulk-import templates (bundled from src/). The Download Template step picks
     one based on the selected format. */
  const TEMPLATE_FILES = {
    quick:    { url: quickTemplate,    name: 'BulkStudents_Quick.xlsx' },
    detailed: { url: detailedTemplate, name: 'BulkStudents_Detailed_Template.xlsx' },
  };
  const downloadTemplate = () => {
    const t = TEMPLATE_FILES[importType] || TEMPLATE_FILES.quick;
    const a = document.createElement('a');
    a.href = t.url;
    a.download = t.name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    showToast('Template downloaded', 'success');
  };

  /* Reset the wizard's file/preview state (on close or format change). */
  const resetImportFile = () => { setImportFile(null); setImportPreview(null); };

  /* Step 3: accept a single .xlsx file and parse its first sheet for preview. */
  const handleImportFile = async (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = ''; // allow re-selecting the same file
    if (!file) return;
    if (!/\.xlsx$/i.test(file.name)) { showToast('Please select an .xlsx file', 'error'); return; }
    setImportFile(file);
    try {
      const XLSX = await import('xlsx');
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const matrix = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
      const headers = (matrix[0] || []).map(h => String(h));
      const rows = matrix.slice(1).filter(r => r.some(c => String(c).trim() !== ''));
      setImportPreview({ headers, rows });
    } catch (err) {
      console.error('Error parsing file:', err);
      showToast('Could not read the file', 'error');
      setImportPreview(null);
    }
  };

  /* Step 4: POST the selected file to the matching bulk-import endpoint. */
  const confirmImport = async () => {
    if (!importFile || !showImport) return;
    const { cls, sec } = showImport;
    const endpoint = importType === 'detailed'
      ? '/api/LaunchSetup/bulk-import-students-detailed'
      : '/api/LaunchSetup/bulk-import-students';
    const fd = new FormData();
    fd.append('gradeId',   cls.id);
    fd.append('sectionId', sec?.sectionID ?? 0);
    fd.append('branchId',  Number(branchID) || 0);
    fd.append('createdBy', Number(sessionStorage.getItem('UserID')) || 0);
    fd.append('file',      importFile);
    /* Manual Registration Number toggle ON ho to backend ko batao — tab wo file ki
       RegistrationNumber column use karta hai (auto-generate nahi), aur wahi number
       screen par dikhता hai. OFF par backend khud number generate karta hai. */
    fd.append('isManualRegNo', !!manualReg);
    setImporting(true);
    try {
      // NOTE: don't set Content-Type — the browser adds the multipart boundary.
      const res = await fetch(buildUrl(endpoint), { method: 'POST', headers: { Accept: '*/*' }, body: fd });
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        showSuccess('Import Complete!', data?.message || 'Student data imported successfully.');
        setShowImport(null); setImportStep(1); resetImportFile();
        getclassesdata();
      } else {
        showToast(data?.message || 'Import failed', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Network error. Please try again.', 'error');
    } finally {
      setImporting(false);
    }
  };

  const allSections = (Array.isArray(classesData) ? classesData : []).flatMap(c => c.sections || []);
  const totalStudents = allSections.reduce((s, sec) => s + (sec.students?.length || 0), 0);
  const totalWithStudents = allSections.filter(sec => (sec.students?.length || 0) > 0).length;


  useEffect(() => {
    getclassesdata();
  }, []);
  
  const getclassesdata = useCallback(async () => {

      try {
        const res      = await fetch(buildUrl(`/api/LaunchSetup/get-class-section-studentlist-by-branch/${branchID}`), { headers: { Accept: '*/*' } });
        const json     = await res.json();
        const d        = json.data ?? {};
        setClassesData(d);
      } catch { showToast('Could not load branch data', 'error'); }
      finally { setLoading(false); }
  }, [setClassesData]);


  if (loading) return <div className="tab-panel active"><SetupLoader label="Loading students…" /></div>;

  return (
    <div className="tab-panel active">
      {/* Manual reg toggle */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 16px', background: 'var(--bg-card)', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-md)', marginBottom: 16, boxShadow: 'var(--shadow-sm)', flexWrap: 'wrap' }}>
        <input type="checkbox" id="manualRegToggle" checked={manualReg} onChange={e => setManualReg(e.target.checked)}
          style={{ width: 16, height: 16, cursor: 'pointer', accentColor: 'var(--brand-primary)', flexShrink: 0 }} />
        <label htmlFor="manualRegToggle" style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', cursor: 'pointer' }}>Manual Registration Number</label>
        <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>(Check this if you want to give Registration Number of your choice to students)</span>
      </div>

      {/* Stats */}
    <div className="stats-strip" style={{ marginBottom: 16, display: 'flex', gap: '16px' }}>
  <div className="stat-mini" style={{ flex: 1, width: '50%' }}>
    <div className="stat-icon" style={{ background: 'rgba(30,58,138,.1)', color: 'var(--brand-primary)' }}>
      <i className="fas fa-user-graduate"></i>
    </div>
    <div>
      <div className="stat-val">{totalStudents}</div>
      <div className="stat-lbl">Total Students</div>
    </div>
  </div>
  <div className="stat-mini" style={{ flex: 1, width: '50%' }}>
    <div className="stat-icon" style={{ background: 'rgba(22,163,74,.1)', color: 'var(--success)' }}>
      <i className="fas fa-layer-group"></i>
    </div>
    <div>
      <div className="stat-val">{totalWithStudents}</div>
      <div className="stat-lbl">Active Sections</div>
    </div>
  </div>
</div>
      {/* Toolbar */}
      <div className="classes-toolbar">
        <div className="toolbar-left">
          <div className="search-box">
            <i className="fas fa-search"></i>
            <input placeholder="Search class or section..." value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} />
          </div>
        </div>
        <div className="toolbar-right">
          {canDownload && (
            <Tooltip text="Download students report as PDF">
              <button className="btn btn-pdf btn-md" onClick={() => downloadStudentReport(classesData, studentStrengths, schoolInfo || {}, showToast)}>
              <i className="fas fa-file-pdf"></i> <span className="pdf-btn-label">Download Report</span>
            </button>
            </Tooltip>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="classes-table-card" style={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch' }}>
        <div className="student-table-head">
          <div className="th">S. No.</div>
          <div className="th">Class</div>
          <div className="th">Section</div>
          <div className="th">Strength</div>
          <div className="th">Actions</div>
          <div className="th" style={{ textAlign: 'center' }}>Details</div>
        </div>
        <div>
          {!paged.length ? (
            <div className="empty-state">
              <div className="empty-icon"><i className="fas fa-user-graduate"></i></div>
              <div className="empty-title">No Classes Found</div>
              <div className="empty-sub">Add classes and sections in the Classes tab first.</div>
            </div>
          ) : paged.map(({ cls, sec }, i) => {
            const key = getKey(cls.id, sec);
            const exp = expandedKey === key;
            const strength = getStrength(cls.id, sec);
            const stuList = getStudents(cls.id, sec);
            const globalIdx = (currentPage - 1) * perPage + i + 1;
            return (
              <div key={key} className="student-row-wrap">
                <div className={`student-row${exp ? ' expanded-row' : ''}`} onClick={() => setExpandedKey(exp ? null : key)}>
                  <div className="td" style={{ color: 'var(--text-muted)', fontWeight: 700, fontSize: 12 }}>{String(globalIdx).padStart(2, '0')}</div>
                  <div className="td">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                      <div className="class-avatar" style={{ background: COLORS[classesData.findIndex(c => c.id === cls.id) % COLORS.length] }}>
                        {cls.name.charAt(0).toUpperCase()}
                      </div>
                      <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>{cls.name}</span>
                    </div>
                  </div>
                  <div className="td">
                    {sec ? <span className="stu-section-pill">{sec.sectionName}</span>
                      : <span style={{ fontSize: 12, color: 'var(--text-muted)', fontStyle: 'italic' }}>No section</span>}
                  </div>
                  {/* Strength */}
                  <div className="td" onClick={e => e.stopPropagation()}>
                    <span style={{ fontSize: 15, fontWeight: 800, color: 'var(--text-primary)' }}>{strength}</span>
                  </div>
                  {/* Action buttons */}
                  <div className="td" style={{ gap: 6, flexWrap: 'wrap' }}>
                    {canCreate && <Tooltip text="Add a new student">
                    <button
                      className="btn btn-primary btn-sm"
                      onClick={e => { e.stopPropagation(); openAddStudent(key); }}
                      style={{ background: 'linear-gradient(135deg,#1E3A8A,#1E40AF)', whiteSpace: 'nowrap' }}>
                      <i className="fas fa-user-plus"></i> Add Student
                    </button>
                    </Tooltip>}
                    {canImport && <Tooltip text={`Bulk import students for ${cls.name}${sec ? ` - Section ${sec.sectionName}` : ''}`}>
                    <button
                      onClick={e => { e.stopPropagation(); setShowImport({ cls, sec }); setImportStep(1); }}
                      style={{ background: '#1E293B', color: '#fff', border: 'none', borderRadius: 8, padding: '7px 11px', cursor: 'pointer', fontSize: 13, display: 'inline-flex', alignItems: 'center' }}>
                      <i className="fas fa-file-import"></i>
                    </button>
                    </Tooltip>}
                    {canDownload && <><Tooltip text={`Download student list for ${cls.name}${sec ? ` - Section ${sec.sectionName}` : ''} as PDF`}>
                    <button
                      onClick={e => { e.stopPropagation(); downloadSectionStudentsReport(cls, sec, schoolInfo || {}, showToast, 'pdf'); }}
                      style={{ background: '#DC2626', color: '#fff', border: 'none', borderRadius: 8, padding: '7px 12px', cursor: 'pointer', fontSize: 12.5, fontWeight: 700, whiteSpace: 'nowrap', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                      <i className="fas fa-file-pdf"></i> PDF
                    </button>
                    </Tooltip>
                    <Tooltip text={`Download student list for ${cls.name}${sec ? ` - Section ${sec.sectionName}` : ''} as Word`}>
                    <button
                      onClick={e => { e.stopPropagation(); downloadSectionStudentsReport(cls, sec, schoolInfo || {}, showToast, 'word'); }}
                      style={{ background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, padding: '7px 12px', cursor: 'pointer', fontSize: 12.5, fontWeight: 700, whiteSpace: 'nowrap', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                      <i className="fas fa-file-word"></i> Word
                    </button>
                    </Tooltip></>}
                  </div>
                  <div className="td" style={{ justifyContent: 'center' }}>
                    <Tooltip text={exp ? 'Hide details' : 'Show details'}>
                    <button className={`expand-btn${exp ? ' open' : ''}`} onClick={e => { e.stopPropagation(); setExpandedKey(exp ? null : key); }}>
                      <i className="fas fa-chevron-down"></i>
                    </button>
                    </Tooltip>
                  </div>
                </div>

                {/* Expanded student list */}
                {exp && (
                  <div className="student-expand">
                    <div style={{ background: 'linear-gradient(135deg,#1E40AF,#1E40AF)', borderRadius: '8px 8px 0 0', padding: '12px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
                      <div style={{ fontSize: 15, fontWeight: 800, color: '#fff' }}>
                        <i className="fas fa-users" style={{ marginRight: 8, opacity: .85 }}></i>
                        Student List — {cls.name}{sec ? ` · Section ${sec.sectionName}` : ''}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ background: 'rgba(255,255,255,.18)', color: '#fff', fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 99 }}>
                          {sec.students.length} student{sec.students.length !== 1 ? 's' : ''}
                        </span>
                        {canCreate && <Tooltip text="Add a new student">
                        <button onClick={() => openAddStudent(key)}
                          style={{ background: 'rgba(255,255,255,.18)', border: '1.5px solid rgba(255,255,255,.35)', color: '#fff', fontSize: 12, fontWeight: 700, padding: '5px 12px', borderRadius: 8, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, transition: 'background .2s', fontFamily: 'var(--font-body)' }}>
                          <i className="fas fa-user-plus"></i> Add Student
                        </button>
                        </Tooltip>}
                      </div>
                    </div>

                    {!sec.students.length ? (
                      <div style={{ textAlign: 'center', padding: '40px 20px', background: 'var(--bg-muted)', borderRadius: '0 0 8px 8px' }}>
                        <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'rgba(30,58,138,.07)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px', fontSize: 26, color: 'var(--brand-primary)' }}>
                          <i className="fas fa-user-graduate"></i>
                        </div>
                        <div style={{ fontSize: 15, fontWeight: 800, color: 'var(--text-primary)', marginBottom: 6 }}>No Students Enrolled Yet</div>
                        <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 18 }}>
                          Add students to <strong>{cls.name}</strong>{sec ? ` – Section ${sec.sectionName}` : ''}
                        </div>
                        {canCreate && (
                          <Tooltip text="Add the first student">
                          <button className="btn btn-primary btn-md" onClick={() => openAddStudent(key)}>
                            <i className="fas fa-user-plus"></i> Add First Student
                          </button>
                          </Tooltip>
                        )}
                      </div>
                    ) : (
                      <div style={{ overflowX: 'auto', border: '1px solid var(--border-light)', borderTop: 'none', borderRadius: '0 0 8px 8px' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 640 }}>
                          <thead>
                            <tr style={{ background: '#1E40AF' }}>
                              {['#', 'Reg No', 'Name', 'Father Name', 'DOB', 'Contact', 'Action'].map(h => (
                                <th key={h} style={{ padding: '11px 12px', fontSize: 11.5, fontWeight: 700, color: '#fff', textAlign: h === 'Action' ? 'center' : 'left', whiteSpace: 'nowrap' }}>{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {sec.students.map((s, si) => {
                              /* API `registerNo` deta hai (raw list), `regNo` nahi — is liye
                                 asal (manual/auto) number yahan dikhao. Sirf `regNo` padhne se
                                 hamesha 245-index fallback chal jata tha. */
                              const displayRegNo = s.registerNo || s.RegisterNo || s.regNo || s.registrationNo || `245-${String(10001 + si).slice(-4)}`;
                              const rowBg = si % 2 === 0 ? 'var(--bg-card)' : 'var(--bg-muted)';
                              const TD = 'padding:10px 12px;border-bottom:1px solid var(--border-light);font-size:13px;';
                              const displayname = `${s.firstName} ${s.lastName}` 
                              return (
                                <tr key={si} style={{ background: rowBg }}>
                                  <td style={{ padding: '10px 12px', borderBottom: '1px solid var(--border-light)', fontWeight: 700, color: 'var(--text-muted)', width: 40 }}>{si + 1}</td>
                                  <td style={{ padding: '10px 12px', borderBottom: '1px solid var(--border-light)', fontWeight: 600, whiteSpace: 'nowrap', fontSize: 13 }}>{displayRegNo}</td>
                                  <td style={{ padding: '10px 12px', borderBottom: '1px solid var(--border-light)', fontWeight: 700, fontSize: 13, color: 'var(--text-primary)' }}>{displayname}</td>
                                  <td style={{ padding: '10px 12px', borderBottom: '1px solid var(--border-light)', fontSize: 13, color: 'var(--text-secondary)' }}>{s.fatherName || '—'}</td>
                                  <td style={{ padding: '10px 12px', borderBottom: '1px solid var(--border-light)', fontSize: 13, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{s.dateOfBirth || '—'}</td>
                                  <td style={{ padding: '10px 12px', borderBottom: '1px solid var(--border-light)', fontSize: 13, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{s.mobileNo || '—'}</td>
                                  <td style={{ padding: '10px 12px', borderBottom: '1px solid var(--border-light)', textAlign: 'center', whiteSpace: 'nowrap' }}>
                                    {canEdit && <Tooltip text="Edit student">
                                    <button onClick={() => openEditStudent(key, s, si)}
                                      style={{ background: 'rgba(30,58,138,.08)', border: '1px solid rgba(30,58,138,.2)', color: 'var(--brand-primary)', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer', marginRight: 5, fontFamily: 'var(--font-body)', fontWeight: 600 }}>
                                      <i className="fas fa-pen"></i>
                                    </button>
                                    </Tooltip>}
                                    {canDelete && <Tooltip text="Delete student">
                                    <button onClick={() => setDeleteStuTarget(s)}
                                      style={{ background: 'rgba(220,38,38,.08)', border: '1px solid rgba(220,38,38,.2)', color: '#DC2626', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer', fontFamily: 'var(--font-body)', fontWeight: 600 }}>
                                      <i className="fas fa-trash"></i>
                                    </button>
                                    </Tooltip>}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                          {sec.students.reduce((s, x) => s + (Number(x.dues) || 0), 0) > 0 && (
                            <tfoot>
                              <tr style={{ background: 'rgba(30,58,138,.05)', borderTop: '2px solid var(--border-light)' }}>
                                <td colSpan={5} style={{ padding: '10px 12px', fontSize: 12.5, fontWeight: 700, color: 'var(--text-muted)' }}>Total Previous Dues</td>
                                <td style={{ padding: '10px 12px', fontSize: 13, fontWeight: 800, color: 'var(--brand-primary)' }}>PKR {stuList.reduce((s, x) => s + (Number(x.dues) || 0), 0).toLocaleString()}</td>
                                <td></td>
                              </tr>
                            </tfoot>
                          )}
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
        <div className="pagination">
          <div className="pagination-info">
            Showing <strong>{paged.length}</strong> of <strong>{filtered.length}</strong> rows
            <span className="per-page-wrap">
              <select
                title="Rows per page"
                className="per-page-select"
                value={perPage}
                onChange={e => { setPerPage(Number(e.target.value)); setPage(1); }}
              >
                {[8, 10, 20, 50, 100].map(n => <option key={n} value={n}>{n}</option>)}
              </select>
            </span>
          </div>
          <div className="pagination-pages">
            <button className="page-btn" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}>
              <i className="fas fa-chevron-left"></i>
            </button>
            {Array.from({ length: Math.min(pages, 5) }, (_, i) => i + 1).map(p => (
              <button key={p} className={`page-btn${currentPage === p ? ' active' : ''}`} onClick={() => setPage(p)}>{p}</button>
            ))}
            <button className="page-btn" onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={currentPage === pages}>
              <i className="fas fa-chevron-right"></i>
            </button>
          </div>
        </div>
      </div>

      {/* Modals */}
      <StudentModal
        open={showStudentModal}
        target={stuTarget}
        editIdx={stuEditIdx}
        editStudent={stuEditData}
        classesData={classesData}
        manualReg={manualReg}
        showToast={showToast}
        onClose={() => setShowStudentModal(false)}
        onSaved={getclassesdata}
      />

      {/* Delete student confirmation */}
      {deleteStuTarget && (
        <div className="modal-overlay open" onClick={e => e.target === e.currentTarget && !deleting && setDeleteStuTarget(null)}>
          <div className="modal modal-sm">
            <div className="modal-header">
              <div>
                <div className="modal-title">Remove Student</div>
                <div className="modal-subtitle">This action cannot be undone</div>
              </div>
              <button className="modal-close" onClick={() => !deleting && setDeleteStuTarget(null)}><i className="fas fa-times"></i></button>
            </div>
            <div className="modal-body">
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', background: 'rgba(220,38,38,.06)', border: '1px solid rgba(220,38,38,.2)', borderRadius: 'var(--radius-md)' }}>
                <div style={{ width: 42, height: 42, borderRadius: '50%', background: 'rgba(220,38,38,.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: '#DC2626', fontSize: 18 }}>
                  <i className="fas fa-trash"></i>
                </div>
                <div style={{ fontSize: 13.5, color: 'var(--text-primary)' }}>
                  Are you sure you want to remove <strong>{deleteStuTarget.name}</strong>?
                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary btn-md" onClick={() => setDeleteStuTarget(null)} disabled={deleting}>Cancel</button>
                <button className="btn btn-danger btn-md" onClick={confirmDeleteStudent} disabled={deleting}>
                  <i className={`fas ${deleting ? 'fa-spinner fa-spin' : 'fa-trash'}`}></i> {deleting ? 'Removing...' : 'Remove'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Import Wizard */}
      {showImport && (
        <div className="modal-overlay open" onClick={e => { if (e.target === e.currentTarget && !importing) { setShowImport(null); setImportStep(1); resetImportFile(); } }}>
          <div className="modal modal-xl">
            <div style={{ background: 'linear-gradient(135deg,#4C1D95,#7C3AED)', padding: '18px 24px', borderRadius: '20px 20px 0 0', flexShrink: 0 }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ color: '#fff', fontWeight: 800, fontSize: 15 }}>Bulk Import Students</div>
                  <div style={{ color: 'rgba(255,255,255,.7)', fontSize: 12, marginTop: 4 }}>
                    {showImport.cls.name}{showImport.sec ? ` · Section ${showImport.sec.sectionName}` : ''}
                  </div>
                </div>
                <button className="modal-close" style={{ background: 'rgba(255,255,255,.15)', color: '#fff' }} onClick={() => { setShowImport(null); setImportStep(1); resetImportFile(); }}>
                  <i className="fas fa-times"></i>
                </button>
              </div>
            </div>
            <div className="modal-body">
              {/* Step indicators */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 24, flexWrap: 'wrap' }}>
                {['Choose Format', 'Download Template', 'Upload File', 'Preview & Import'].map((label, i) => {
                  const stepNum = i + 1;
                  const state = importStep === stepNum ? 'active' : importStep > stepNum ? 'done' : 'idle';
                  return (
                    <React.Fragment key={i}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 12px', borderRadius: 99, fontSize: 11, fontWeight: 700, border: '1.5px solid', borderColor: state === 'active' ? '#7C3AED' : state === 'done' ? '#16A34A' : 'var(--border-light)', background: state === 'active' ? '#EDE9FE' : state === 'done' ? '#DCFCE7' : 'var(--bg-card)', color: state === 'active' ? '#6D28D9' : state === 'done' ? '#15803D' : 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                        {state === 'done' ? <i className="fas fa-check"></i> : stepNum}
                        {(state === 'active') && <span style={{ marginLeft: 3 }}>{label}</span>}
                      </div>
                      {i < 3 && <div style={{ flex: 1, height: 2, background: state === 'done' ? '#16A34A' : 'var(--border-light)', minWidth: 10 }}></div>}
                    </React.Fragment>
                  );
                })}
              </div>

              {importStep === 1 && (
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 14 }}>Select Import Format</div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                    {[{ key: 'quick', label: 'Quick Import', icon: 'fa-bolt', desc: 'Name, class, section, contact. Fastest option.', cols: 4 },
                      { key: 'detailed', label: 'Detailed Import', icon: 'fa-file-alt', desc: 'Full student profile with all optional fields.', cols: 12 }
                    ].map(opt => (
                      <div key={opt.key} onClick={() => { setImportType(opt.key); resetImportFile(); }}
                        style={{ border: `2px solid ${importType === opt.key ? '#7C3AED' : 'var(--border-light)'}`, borderRadius: 'var(--radius-lg)', padding: 18, cursor: 'pointer', background: importType === opt.key ? '#F5F3FF' : 'var(--bg-card)' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                          <div style={{ width: 36, height: 36, borderRadius: 9, background: importType === opt.key ? '#EDE9FE' : 'var(--bg-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#7C3AED', fontSize: 15 }}>
                            <i className={`fas ${opt.icon}`}></i>
                          </div>
                          <div style={{ fontWeight: 800, fontSize: 14, color: 'var(--text-primary)' }}>{opt.label}</div>
                        </div>
                        <div style={{ fontSize: 12.5, color: 'var(--text-muted)', lineHeight: 1.6 }}>{opt.desc}</div>
                        <div style={{ marginTop: 8, fontSize: 11, fontWeight: 700, color: '#7C3AED' }}>{opt.cols} columns</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {importStep === 2 && (
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 14 }}>Download Template</div>
                  <div style={{ background: 'linear-gradient(135deg,#15803D,#166534)', borderRadius: 'var(--radius-md)', padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
                    <i className="fas fa-file-excel" style={{ color: '#fff', fontSize: 28 }}></i>
                    <div style={{ flex: 1 }}>
                      <div style={{ color: '#fff', fontWeight: 700 }}>{importType === 'quick' ? 'Quick' : 'Detailed'} Student Import Template.xlsx</div>
                      <div style={{ color: 'rgba(255,255,255,.7)', fontSize: 11 }}>Excel format · Ready to fill</div>
                    </div>
                    <Tooltip text="Download the Excel template">
                    <button className="btn btn-md" style={{ background: '#fff', color: '#15803D', fontWeight: 700 }} onClick={downloadTemplate}>
                      <i className="fas fa-download"></i> Download
                    </button>
                    </Tooltip>
                  </div>
                  <div style={{ padding: '10px 14px', background: 'rgba(245,158,11,.06)', border: '1px solid rgba(245,158,11,.2)', borderRadius: 'var(--radius-md)', fontSize: 12, color: 'var(--text-secondary)' }}>
                    <i className="fas fa-exclamation-triangle" style={{ color: 'var(--warning)', marginRight: 6 }}></i>
                    <strong>Note:</strong> Do not change column headers. Date format: DD/MM/YYYY. Gender: Male/Female/Other.
                  </div>
                </div>
              )}

              {importStep === 3 && (
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 14 }}>Upload Filled Template</div>
                  <input
                    ref={importInputRef}
                    type="file"
                    accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    onChange={handleImportFile}
                    style={{ display: 'none' }}
                  />
                  <Tooltip text="Choose an .xlsx file to upload">
                  <div onClick={() => importInputRef.current?.click()}
                    style={{ border: `2px dashed ${importFile ? '#16A34A' : 'var(--border-med)'}`, borderRadius: 'var(--radius-lg)', padding: 40, textAlign: 'center', cursor: 'pointer', background: importFile ? 'rgba(22,163,74,.05)' : 'var(--bg-muted)' }}>
                    <i className={`fas ${importFile ? 'fa-file-excel' : 'fa-cloud-upload-alt'}`} style={{ fontSize: 40, color: importFile ? '#16A34A' : 'var(--brand-primary)', opacity: importFile ? 1 : .4, display: 'block', marginBottom: 12 }}></i>
                    {importFile ? (
                      <>
                        <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 6 }}>{importFile.name}</div>
                        <div style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>
                          {(importFile.size / 1024).toFixed(1)} KB{importPreview ? ` · ${importPreview.rows.length} row${importPreview.rows.length !== 1 ? 's' : ''} detected` : ''} · click to change
                        </div>
                      </>
                    ) : (
                      <>
                        <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 6 }}>Click to browse</div>
                        <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginBottom: 14 }}>Select your filled template</div>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Supported: .xlsx only</div>
                      </>
                    )}
                  </div>
                  </Tooltip>
                </div>
              )}

              {importStep === 4 && (
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 14 }}>
                    Preview Import Data{importPreview ? ` · ${importPreview.rows.length} row${importPreview.rows.length !== 1 ? 's' : ''}` : ''}
                  </div>
                  {!importPreview || importPreview.rows.length === 0 ? (
                    <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
                      <i className="fas fa-table" style={{ fontSize: 32, opacity: .3, display: 'block', marginBottom: 12 }}></i>
                      <div style={{ fontSize: 14, fontWeight: 600 }}>No data to preview</div>
                      <div style={{ fontSize: 12.5, marginTop: 4 }}>Upload a file in step 3 first</div>
                    </div>
                  ) : (
                    <div style={{ overflow: 'auto', maxHeight: 360, border: '1px solid var(--border-light)', borderRadius: 'var(--radius-md)' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 640 }}>
                        <thead>
                          <tr style={{ background: '#4C1D95' }}>
                            <th style={{ padding: '9px 10px', fontSize: 11, fontWeight: 700, color: '#fff', textAlign: 'left', whiteSpace: 'nowrap' }}>#</th>
                            {importPreview.headers.map((h, hi) => (
                              <th key={hi} style={{ padding: '9px 10px', fontSize: 11, fontWeight: 700, color: '#fff', textAlign: 'left', whiteSpace: 'nowrap' }}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {importPreview.rows.slice(0, 50).map((r, ri) => (
                            <tr key={ri} style={{ background: ri % 2 === 0 ? 'var(--bg-card)' : 'var(--bg-muted)' }}>
                              <td style={{ padding: '8px 10px', borderBottom: '1px solid var(--border-light)', fontSize: 12, fontWeight: 700, color: 'var(--text-muted)' }}>{ri + 1}</td>
                              {importPreview.headers.map((_, ci) => (
                                <td key={ci} style={{ padding: '8px 10px', borderBottom: '1px solid var(--border-light)', fontSize: 12.5, color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{String(r[ci] ?? '')}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      {importPreview.rows.length > 50 && (
                        <div style={{ padding: '8px 12px', fontSize: 11.5, color: 'var(--text-muted)', background: 'var(--bg-muted)' }}>
                          Showing first 50 of {importPreview.rows.length} rows. All rows will be imported.
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24, paddingTop: 16, borderTop: '1px solid var(--border-light)', flexWrap: 'wrap', gap: 10 }}>
                <div>{importStep > 1 && <button className="btn btn-secondary btn-md" onClick={() => setImportStep(s => s - 1)} disabled={importing}><i className="fas fa-arrow-left"></i> Back</button>}</div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button className="btn btn-ghost btn-md" onClick={() => { setShowImport(null); setImportStep(1); resetImportFile(); }} disabled={importing}>Cancel</button>
                  {importStep < 4
                    ? <button
                        className="btn btn-md"
                        style={{ background: 'linear-gradient(135deg,#7C3AED,#6D28D9)', color: '#fff', opacity: (importStep === 3 && !importFile) ? .5 : 1 }}
                        disabled={importStep === 3 && !importFile}
                        onClick={() => setImportStep(s => s + 1)}>
                        Next <i className="fas fa-arrow-right"></i>
                      </button>
                    : <Tooltip text="Import students from the uploaded file">
                      <button
                        className="btn btn-md"
                        style={{ background: 'linear-gradient(135deg,#15803D,#166534)', color: '#fff', opacity: (!importFile || importing) ? .6 : 1 }}
                        disabled={!importFile || importing}
                        onClick={confirmImport}>
                        <i className={`fas ${importing ? 'fa-spinner fa-spin' : 'fa-check'}`}></i> {importing ? 'Importing…' : 'Confirm Import'}
                      </button>
                      </Tooltip>}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
