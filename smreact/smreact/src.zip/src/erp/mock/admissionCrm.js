/* ═══════════════════════════════════════════════════════════════════
   Admission CRM Module — seed data
   Ported from ~/Desktop/ERP-HTML/Admissions CRM .html
   ═══════════════════════════════════════════════════════════════════ */

/* Front-desk officers who can be assigned to a lead. */
export const mockCrmOfficers = [
  { name: 'Sarah Khan',  initials: 'SK', color: '#1E40AF' },
  { name: 'Ahmed Raza',  initials: 'AR', color: '#D97706' },
  { name: 'Maria Ali',   initials: 'MA', color: '#7C3AED' },
  { name: 'Raza Ahmed',  initials: 'RA', color: '#16A34A' },
];

/* Inbound channels — used in the source filter + per-lead source pill. */
export const mockCrmSources = [
  { name: 'Facebook',  color: '#1877F2', icon: 'fa-facebook-f' },
  { name: 'Walk-in',   color: '#16A34A', icon: 'fa-person-walking' },
  { name: 'WhatsApp',  color: '#25D366', icon: 'fa-whatsapp' },
  { name: 'Instagram', color: '#E1306C', icon: 'fa-instagram' },
  { name: 'Reference', color: '#7C3AED', icon: 'fa-user-group' },
  { name: 'Google',    color: '#EA4335', icon: 'fa-google' },
  { name: 'Campaign',  color: '#D97706', icon: 'fa-bullhorn' },
  { name: 'Website',   color: '#0284C7', icon: 'fa-globe' },
];

/* The 6 lifecycle statuses a lead can carry. */
export const mockCrmStatuses = [
  { label: 'Interested',           cls: 'status-interested',   color: '#0284C7' },
  { label: 'Call Back Later',      cls: 'status-callback',     color: '#D97706' },
  { label: 'Visit Scheduled',      cls: 'status-visit',        color: '#7C3AED' },
  { label: 'Waiting Decision',     cls: 'status-waiting',      color: '#64748B' },
  { label: 'Admission Confirmed',  cls: 'status-confirmed',    color: '#16A34A' },
  { label: 'Not Interested',       cls: 'status-notinterested', color: '#DC2626' },
];

/* Active leads — the main inbox shown on the Active Leads tab.
   Each lead may carry a `notes[]` array (newest first when rendered)
   and a `followup` urgency flag. */
export const mockCrmLeads = [
  {
    id: 'L001', name: 'Tariq Mehmood', phone: '0321-1111001', whatsapp: '0321-1111001', email: null,
    students: 2, classes: 'Class 3, Class 5', officer: 'Sarah Khan',
    status: 'Interested', source: 'Facebook', followup: 'overdue',
    lastFu: '2026-05-18', nextFu: '2026-05-20', initials: 'TM', color: '#1E40AF',
    assignedDate: '2026-05-10', address: 'Gulberg III, Lahore', reminder: true,
    notes: [
      { date: '2026-05-18', time: '9:30 AM',  staff: 'Sarah Khan', text: 'Initial inquiry via Facebook. Responded with school details. Parent asked about admission timeline & seat availability.', nextFu: '2026-05-20', status: 'Interested' },
    ],
  },
  {
    id: 'L002', name: 'Amna Siddiqui', phone: '0300-2222002', whatsapp: '0300-2222002', email: 'amna.s@example.com',
    students: 1, classes: 'Nursery', officer: 'Ahmed Raza',
    status: 'Call Back Later', source: 'WhatsApp', followup: 'overdue',
    lastFu: '2026-05-17', nextFu: '2026-05-19', initials: 'AS', color: '#D97706',
    assignedDate: '2026-05-09', address: null, reminder: true,
    notes: [
      { date: '2026-05-17', time: '11:00 AM', staff: 'Ahmed Raza', text: 'First call made. Parent available & interested. Asked about transport timings. Will decide after discussing with spouse.', nextFu: '2026-05-19', status: 'Call Back Later' },
    ],
  },
  {
    id: 'L003', name: 'Bilal Chaudhry', phone: '0333-3333003', whatsapp: null, email: null,
    students: 3, classes: 'Class 1, Class 3, Class 6', officer: 'Maria Ali',
    status: 'Waiting Decision', source: 'Reference', followup: 'overdue',
    lastFu: '2026-05-16', nextFu: '2026-05-18', initials: 'BC', color: '#7C3AED',
    assignedDate: '2026-05-05', address: 'Johar Town, Lahore', reminder: true,
    notes: [
      { date: '2026-05-16', time: '2:00 PM', staff: 'Maria Ali', text: 'Follow-up call. Parent still deciding. Comparing with two other schools. Offered a school visit to help them decide.', nextFu: '2026-05-18', status: 'Waiting Decision' },
    ],
  },
  {
    id: 'L004', name: 'Farhan Akhtar', phone: '0311-4444004', whatsapp: '0311-4444004', email: null,
    students: 1, classes: 'Class 4', officer: 'Sarah Khan',
    status: 'Interested', source: 'Walk-in', followup: 'overdue',
    lastFu: '2026-05-15', nextFu: '2026-05-17', initials: 'FA', color: '#16A34A',
    assignedDate: '2026-05-12', address: null, reminder: false,
    notes: [
      { date: '2026-05-15', time: '4:00 PM', staff: 'Raza Ahmed', text: 'Walk-in inquiry at front desk. Collected basic info & handed brochure. Interested in Class 4 (sibling already enrolled).', nextFu: '2026-05-17', status: 'Interested' },
    ],
  },
  {
    id: 'L009', name: 'Ahmed Raza Khan', phone: '0321-4567890', whatsapp: '0321-4567890', email: null,
    students: 2, classes: 'Class 3, Class 5', officer: 'Sarah Khan',
    status: 'Interested', source: 'WhatsApp', followup: 'today',
    lastFu: '2026-05-24', nextFu: '2026-05-26', initials: 'AK', color: '#1E40AF',
    assignedDate: '2026-05-20', address: 'DHA Phase 5, Lahore', reminder: true,
    notes: [
      { date: '2026-05-26', time: '10:30 AM', staff: 'Sarah Khan', text: 'Called parent. Shared complete fee structure. Parent very interested — asked about sibling discount. Will visit school Saturday.', nextFu: '2026-05-28', status: 'Interested' },
      { date: '2026-05-24', time: '3:15 PM',  staff: 'Ahmed Raza', text: 'WhatsApp message sent with school brochure. Parent replied positively — requested to see classroom facilities.', nextFu: '2026-05-26', status: 'Visit Scheduled' },
    ],
  },
  {
    id: 'L010', name: 'Sadia Khalid', phone: '0300-9876543', whatsapp: null, email: 'sadia.k@example.com',
    students: 1, classes: 'Nursery', officer: 'Ahmed Raza',
    status: 'Visit Scheduled', source: 'Facebook', followup: 'today',
    lastFu: '2026-05-24', nextFu: '2026-05-26', initials: 'SK', color: '#16A34A',
    assignedDate: '2026-05-18', address: null, reminder: true,
    notes: [
      { date: '2026-05-24', time: '12:15 PM', staff: 'Ahmed Raza', text: 'Visit confirmed for Tuesday 10 am. Parent will bring previous report card. Wants to see Nursery section.', nextFu: '2026-05-26', status: 'Visit Scheduled' },
    ],
  },
  {
    id: 'L021', name: 'Muhammad Hassan', phone: '0333-1122334', whatsapp: '0333-1122334', email: null,
    students: 3, classes: 'Class 1, Class 3, Class 6', officer: 'Maria Ali',
    status: 'Call Back Later', source: 'Reference', followup: 'tmrw',
    lastFu: '2026-05-24', nextFu: '2026-05-27', initials: 'MH', color: '#D97706',
    assignedDate: '2026-05-22', address: 'Model Town, Lahore', reminder: true,
    notes: [
      { date: '2026-05-24', time: '5:40 PM', staff: 'Maria Ali', text: 'Referred by Mr. Imran (parent of Class 7). Quick chat — wants to discuss fee plan for all three children. Asked to call back tomorrow evening.', nextFu: '2026-05-27', status: 'Call Back Later' },
    ],
  },
  {
    id: 'L030', name: 'Nadia Perveen', phone: '0311-2828289', whatsapp: '0311-2828289', email: null,
    students: 2, classes: 'Class 5, Class 6', officer: 'Sarah Khan',
    status: 'Interested', source: 'Walk-in', followup: 'normal',
    lastFu: '2026-05-19', nextFu: '2026-05-30', initials: 'NP', color: '#1E40AF',
    assignedDate: '2026-05-19', address: null, reminder: false,
    notes: [
      { date: '2026-05-19', time: '11:50 AM', staff: 'Sarah Khan', text: 'Walk-in visit with both children. Took campus tour. Liked the science lab. Will revert after spouse approval.', nextFu: '2026-05-30', status: 'Interested' },
    ],
  },
];

/* Inactive — converted to a confirmed admission. */
export const mockCrmConverted = [
  { id: 'C001', name: 'Zubair Ahmed',   phone: '0321-1111222', convertedDate: '2026-05-18', students: 2, classes: 'Class 2, Class 4',  officer: 'Sarah Khan', source: 'Facebook',  initials: 'ZA', color: '#16A34A', feeCategory: 'High Fee' },
  { id: 'C002', name: 'Farida Shaheen', phone: '0300-3344556', convertedDate: '2026-05-15', students: 1, classes: 'Nursery',           officer: 'Ahmed Raza', source: 'Instagram', initials: 'FS', color: '#16A34A', feeCategory: 'Mid Fee'  },
  { id: 'C003', name: 'Tariq Khan',     phone: '0333-7788990', convertedDate: '2026-05-10', students: 3, classes: 'Class 5, 7, 8',     officer: 'Maria Ali',  source: 'Reference', initials: 'TK', color: '#16A34A', feeCategory: 'Mid Fee'  },
  { id: 'C004', name: 'Saima Iqbal',    phone: '0311-2244668', convertedDate: '2026-05-08', students: 2, classes: 'Class 1, Class 3',  officer: 'Sarah Khan', source: 'Walk-in',   initials: 'SI', color: '#16A34A', feeCategory: 'Mid Fee'  },
  { id: 'C005', name: 'Imran Sheikh',   phone: '0345-9988221', convertedDate: '2026-05-04', students: 1, classes: 'Class 6',           officer: 'Raza Ahmed', source: 'WhatsApp',  initials: 'IS', color: '#16A34A', feeCategory: 'High Fee' },
  { id: 'C006', name: 'Rabia Yusuf',    phone: '0300-4477889', convertedDate: '2026-04-28', students: 2, classes: 'Nursery, Class 2',  officer: 'Maria Ali',  source: 'Reference', initials: 'RY', color: '#16A34A', feeCategory: 'Mid Fee'  },
];

/* Inactive — rejected with a reason. */
export const mockCrmNotInterested = [
  { id: 'N001', name: 'Nadia Akhtar',   phone: '0321-8877665', reason: 'High Fee',             lastFu: '2026-05-12', classes: 'Class 4',          officer: 'Sarah Khan', source: 'Facebook',  initials: 'NA', color: '#DC2626' },
  { id: 'N002', name: 'Bilal Mahmood',  phone: '0300-4433221', reason: 'Admitted Elsewhere',   lastFu: '2026-05-08', classes: 'Nursery, Class 2', officer: 'Ahmed Raza', source: 'Walk-in',   initials: 'BM', color: '#DC2626' },
  { id: 'N003', name: 'Hassan Iqbal',   phone: '0333-1122446', reason: 'Distance / Transport', lastFu: '2026-05-05', classes: 'Class 3',          officer: 'Maria Ali',  source: 'Walk-in',   initials: 'HI', color: '#DC2626' },
  { id: 'N004', name: 'Sumera Naveed',  phone: '0345-6655443', reason: 'High Fee',             lastFu: '2026-05-01', classes: 'Class 1, Class 5', officer: 'Sarah Khan', source: 'Instagram', initials: 'SN', color: '#DC2626' },
];

/* Reason tags used by the Not Interested modal. */
export const mockCrmReasons = [
  'High Fee', 'Admitted Elsewhere', 'Distance / Transport', 'Curriculum Mismatch',
  'Schedule Issue', 'No Response', 'Other',
];

/* School identity reused by report headers. */
export const mockCrmSchool = {
  name:     'SchoolMentor ERP — Lahore Campus',
  monogram: 'SM',
  session:  'Academic Session 2026',
};

export const mockCrmCurrentUser = 'Sarah Khan';
export const mockCrmNextLeadId  = 31;
