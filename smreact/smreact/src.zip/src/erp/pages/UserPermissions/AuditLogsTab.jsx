import React, { useEffect, useMemo, useState } from 'react';
import Tooltip from '../../components/Tooltip';
import { auditTone, initialsOf } from './permissionsData';

const PAGE_STEP = 100;

/* ═══════════════════════════════════════════════════════════════════
   AUDIT LOGS TAB — filter bar + table
   ═══════════════════════════════════════════════════════════════════ */
/* Date range ab SERVER par lagti hai: parent (UserPermissions) usi se
   /get-activity-logs-by-date-range call karta hai. Pehle poori branch ka
   record aata tha aur ye do input sirf client-side chhantai karte the —
   wohi call slow ho kar timeout karne lagi thi. Search aur action-type
   filter client-side hi hain (wo already laayi hui rows par chalte hain). */
export default function AuditLogsTab({
  auditLog,
  loading = false,
  fromDate = '',
  toDate = '',
  onRangeChange,
}) {
  const [search, setSearch] = useState('');
  const [fType,  setFType]  = useState('all');
  const fFrom = fromDate;
  const fTo   = toDate;
  const setFFrom = (v) => onRangeChange?.(v, fTo);
  const setFTo   = (v) => onRangeChange?.(fFrom, v);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return auditLog.filter(a => {
      if (fType !== 'all' && a.type !== fType) return false;
      if (!q) return true;
      return `${a.user} ${a.action} ${a.screen} ${a.detail} ${a.performedBy} ${a.role} ${a.record}`.toLowerCase().includes(q);
    });
    /* fFrom/fTo yahan deps me NAHI — wo server par lagti hain aur badalne
       par parent nayi rows bhej deta hai. */
  }, [auditLog, search, fType]);

  /* Ek din me hi 12k+ rows aati hain — sab DOM me daalna page jama deta
     hai, is liye PAGE_STEP ki qist me dikhao. Filter badle to wapas shuru. */
  const [visibleCount, setVisibleCount] = useState(PAGE_STEP);
  useEffect(() => { setVisibleCount(PAGE_STEP); }, [search, fType, fromDate, toDate]);

  return (
    <>
      <div className="up-filters up-filters--audit">
        <div className="up-search">
          <i className="fa-solid fa-magnifying-glass up-search-ic" aria-hidden="true"></i>
          <input
            type="text"
            className="up-search-input"
            placeholder="Search by user or action…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Search audit log"
          />
          {search && (
            <Tooltip text="Clear search">
              <button type="button" className="up-search-clear" onClick={() => setSearch('')} aria-label="Clear search">
                <i className="fa-solid fa-xmark" aria-hidden="true"></i>
              </button>
            </Tooltip>
          )}
        </div>
        <Tooltip text="Filter logs by action type">
          <select className="up-select" value={fType} onChange={(e) => setFType(e.target.value)} aria-label="Filter by action type">
            <option value="all">All Actions</option>
            <option value="assign">Permission Assigned</option>
            <option value="role">Role Changed</option>
            <option value="activate">User Activated</option>
            <option value="deactivate">User Deactivated</option>
            <option value="remove">Permission Removed</option>
          </select>
        </Tooltip>
        <Tooltip text="From date (inclusive)">
          <input
            type="date"
            className="up-input"
            value={fFrom}
            onChange={(e) => setFFrom(e.target.value)}
            aria-label="From date"
          />
        </Tooltip>
        <Tooltip text="To date (inclusive)">
          <input
            type="date"
            className="up-input"
            value={fTo}
            onChange={(e) => setFTo(e.target.value)}
            aria-label="To date"
            min={fFrom || undefined}
          />
        </Tooltip>
      </div>

      {loading && auditLog.length === 0 ? (
        <div className="up-empty">
          <div className="up-empty-ic"><i className="fa-solid fa-spinner fa-spin" aria-hidden="true"></i></div>
          <div className="up-empty-title">Loading audit logs…</div>
          <div className="up-empty-sub">Fetching activity logs from the server, please wait.</div>
        </div>
      ) : filtered.length === 0 ? (
        <div className="up-empty">
          <div className="up-empty-ic"><i className="fa-solid fa-clipboard-list" aria-hidden="true"></i></div>
          <div className="up-empty-title">No audit events found</div>
          <div className="up-empty-sub">Try adjusting your filters.</div>
        </div>
      ) : (
        <div className="up-table">
          <div className="up-table-head" style={{ gridTemplateColumns: '150px 1fr 150px 1.2fr 2fr 1fr' }}>
            <div className="th">Date &amp; Time</div>
            <div className="th">User</div>
            <div className="th">Action</div>
            <div className="th">Screen</div>
            <div className="th">Detail</div>
            <div className="th">Performed By</div>
          </div>
          {filtered.slice(0, visibleCount).map(a => (
            <div key={a.id} className="up-table-row" style={{ gridTemplateColumns: '150px 1fr 150px 1.2fr 2fr 1fr' }}>
              <div className="td up-emp-text" style={{ gap: 2 }}>
                <div className="up-emp-name" style={{ fontSize: 12.5 }}>{a.date}</div>
                <div className="up-emp-meta">{a.time}</div>
              </div>
              <div className="td up-emp">
                <Tooltip text={`Target user: ${a.user}`}>
                  <div className="up-avatar up-avatar--sm">{initialsOf(a.user)}</div>
                </Tooltip>
                <div className="up-emp-text">
                  <div className="up-emp-name" style={{ fontSize: 12.5 }}>{a.user}</div>
                </div>
              </div>
              <div className="td">
                <Tooltip text={`Action type: ${a.action}`}>
                  <span className={`up-badge up-badge--${auditTone(a.type)}`}>{a.action}</span>
                </Tooltip>
              </div>
              {/* ERP ki wo screen jahan ye kaam hua — module + action se
                  (resolveErpScreen, rolesService). */}
              <div className="td" style={{ fontSize: 12.5, fontWeight: 600, color: '#334155' }}>
                {a.screen || '—'}
              </div>
              <div className="td" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 12.5, fontStyle: 'italic', color: '#1E3A5F', lineHeight: 1.5 }}>
                {a.detail}
                {a.record && (
                  <div style={{ fontStyle: 'normal', fontWeight: 600, fontSize: 11.5, color: '#64748B', marginTop: 2 }}>
                    Record: {a.record}
                  </div>
                )}
              </div>
              <div className="td up-emp">
                <Tooltip text={`Performed by: ${a.performedBy}`}>
                  <div className="up-avatar up-avatar--sm" style={{ background: 'linear-gradient(135deg,#475569,#64748B)' }}>
                    {initialsOf(a.performedBy)}
                  </div>
                </Tooltip>
                <div className="up-emp-text">
                  <div className="up-emp-meta" style={{ fontWeight: 600, color: '#334155' }}>{a.performedBy}</div>
                  {a.role && <div className="up-emp-meta" style={{ fontSize: 11, color: '#64748B' }}>{a.role}</div>}
                </div>
              </div>
            </div>
          ))}
          {(filtered.length > visibleCount || loading) && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, padding: 14, fontSize: 12.5, color: '#64748B' }}>
              <span>Showing {Math.min(visibleCount, filtered.length)} of {filtered.length}</span>
              {loading && <span><i className="fa-solid fa-spinner fa-spin" aria-hidden="true"></i> Loading more…</span>}
              {filtered.length > visibleCount && (
                <button type="button" className="up-btn up-btn-ghost" onClick={() => setVisibleCount((n) => n + PAGE_STEP)}>
                  Show more
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </>
  );
}
