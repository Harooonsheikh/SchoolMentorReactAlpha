// ══════════════════════════════════════════════════════════════════
//  Combined Assessment Result — API service
//  All endpoints from the Combined Assessment Result module README.
//  Uses buildUrl (configured base) + bearer token from sessionStorage.
// ══════════════════════════════════════════════════════════════════
import { buildUrl } from '../../utils/apiConfig';

const token     = () => sessionStorage.getItem('token') || '';
const branchID  = () => Number(sessionStorage.getItem('branchID')) || 0;
const authHeaders = (extra = {}) => ({ Accept: '*/*', Authorization: `bearer ${token()}`, ...extra });

async function readJson(res, label) {
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const msg = (data && (data.message || data.title || data.error)) || `${label} failed: ${res.status}`;
    const err = new Error(msg);
    err.serverMessage = data && (data.message || data.title);
    err.status = res.status;
    throw err;
  }
  return data;
}

const getJson  = (path)        => fetch(buildUrl(path), { method: 'GET',    headers: authHeaders() }).then(r => readJson(r, `GET ${path}`));
const postJson = (path, body)  => fetch(buildUrl(path), { method: 'POST',   headers: authHeaders({ 'Content-Type': 'application/json' }), body: JSON.stringify(body) }).then(r => readJson(r, `POST ${path}`));
const delJson  = (path)        => fetch(buildUrl(path), { method: 'DELETE', headers: authHeaders() }).then(r => readJson(r, `DELETE ${path}`));

/* examIDs are repeated query params: examIDs=2&examIDs=3 */
const examIdsQS = (ids = []) => ids.map(id => `examIDs=${encodeURIComponent(id)}`).join('&');

/* ── List (page load) ──
   The endpoint's model marks CombinedResultName / SubExams / ClassSectionIDs as
   required for every action, so they must be sent (with defaults) even for get. */
export const listCombinedResults = () =>
  postJson('/api/combinedassessmentcrud', {
    action: 'get',
    branchID: branchID(),
    combinedResultName: 'get',
    mainExamID: 0,
    subExams: [],
    classSectionIDs: [],
  });

/* ── Create modal ── */
export const getExamsForModal = (termID, empID) =>
  getJson(`/api/getexamsbybranchidtermid?branchID=${branchID()}&termID=${termID}&empID=${empID}`);

/* The dedicated getsubexamtotalmarks endpoint 404s; instead derive the original
   total the same way Single Assessment does — sum of subject totals from
   getsasubjectbybranchclassandtermtotalsum (totalMarksSum on the first row, or
   sum the per-subject totals as a fallback). */
export const getSubExamTotalMarks = async (examID, classID, sectionID, termID) => {
  const params = new URLSearchParams({
    branchID:  String(branchID()),
    classID:   String(classID),
    termID:    String(termID ?? ''),
    ExamID:    String(examID),
    sectionID: String(sectionID),
    pageNo:    '1',
  });
  const json = await getJson(`/api/getsasubjectbybranchclassandtermtotalsum?${params.toString()}`);
  const subjects = Array.isArray(json) ? json : (json?.data || []);
  let originalTotalMarks = Number(subjects[0]?.totalMarksSum) || 0;
  if (!originalTotalMarks && subjects.length) {
    originalTotalMarks = subjects.reduce((a, s) => a + (Number(s.totalMarks ?? s.totalmarks ?? s.marks ?? 0) || 0), 0);
  }
  return { examID, originalTotalMarks };
};

export const getCommonClasses = (examIDs) =>
  getJson(`/api/getcommonclassesbyexams?branchID=${branchID()}&${examIdsQS(examIDs)}`);

/* payload: { combinedResultName, mainExamID, subExams:[{examID,weightage}], classSectionIDs:[{classID,sectionID}] } */
export const createCombinedResult = (payload) =>
  postJson('/api/combinedassessmentcrud', { action: 'insert', branchID: branchID(), ...payload });

/* ── Publish / Unpublish ── */
export const publishCombinedResult = ({ combinedResultID, classID, sectionID, isPublished }) =>
  postJson('/api/publishcombinedresult', { combinedResultID, classID, sectionID, isPublished });

/* ── Student table (call both, match by studentID) ── */
export const getCaObtainedMarks = (subExamIDs, gradeID, sectionID) =>
  getJson(`/api/getcaobtainedmarkssumbyexamids?${examIdsQS(subExamIDs)}&gradeID=${gradeID}&sectionID=${sectionID}`);

export const getSaTotalMarks = (mainExamIDs, gradeID, sectionID) =>
  getJson(`/api/getsatotalsumbymultiexamids?${examIdsQS(mainExamIDs)}&branchID=${branchID()}&gradeID=${gradeID}&sectionID=${sectionID}`);

/* Exam APIs often send subjectName empty and a numeric subjectID that does not
   match LaunchSetup IDs. UI must never show that ID — resolve a real name. */
export function saIsPlaceholderName(name, subjectID) {
  const n = String(name || '').trim();
  if (!n) return true;
  if (subjectID != null && n === String(subjectID)) return true;
  return /^\d+$/.test(n);
}

export function saAttachDisplayNames(saList, classSubjects = []) {
  const byId = {};
  const unused = [];
  (classSubjects || []).forEach(s => {
    const id = Number(s.subjectID ?? s.SubjectID ?? 0);
    const nm = String(s.subjectName ?? s.SubjectName ?? s.name ?? '').trim();
    if (!nm || saIsPlaceholderName(nm, id)) return;
    if (id) byId[id] = nm;
    if (!unused.some(u => u.toLowerCase() === nm.toLowerCase())) unused.push(nm);
  });
  const used = new Set();
  return (saList || []).map(s => {
    let name = String(s?.subjectName || '').trim();
    if (!saIsPlaceholderName(name, s?.subjectID)) {
      used.add(name.toLowerCase());
      return { ...s, subjectName: name };
    }
    const mapped = byId[Number(s.subjectID)];
    if (mapped) {
      used.add(mapped.toLowerCase());
      return { ...s, subjectName: mapped };
    }
    const next = unused.find(n => !used.has(n.toLowerCase()));
    if (next) {
      used.add(next.toLowerCase());
      return { ...s, subjectName: next };
    }
    return { ...s, subjectName: '' };
  });
}

const classSubjCache = new Map();
async function fetchClassSubjectsLite(classID, sectionID) {
  const key = `${classID}|${sectionID}`;
  if (classSubjCache.has(key)) return classSubjCache.get(key);
  const pending = (async () => {
    try {
      const empID = sessionStorage.getItem('employee_ID');
      const json = await getJson(`/get-subjects_byEmployeeID/${classID}/${sectionID}/${empID}`);
      return json?.data || (Array.isArray(json) ? json : []) || [];
    } catch {
      return [];
    }
  })();
  classSubjCache.set(key, pending);
  return pending;
}

/* ── Main-exam per-subject marks (for the card's subject table) ── */
export const getMainExamSubjects = async ({ classID, sectionID, termID, examID }) => {
  const params = new URLSearchParams({
    branchID: String(branchID()), classID: String(classID), termID: String(termID ?? ''),
    ExamID: String(examID), sectionID: String(sectionID), pageNo: '1',
  });
  const j = await getJson(`/api/getsasubjectbybranchclassandterm?${params.toString()}`);
  const list = (Array.isArray(j) ? j : (j?.data || j?.Data || [])).map(it => {
    const subjectID = Number(it.subjectID ?? it.SubjectID ?? 0);
    const rawName = String(it.subjectName ?? it.name ?? it.subject ?? it.SubjectName ?? '').trim();
    return {
      id: Number(it.id ?? it.ID ?? 0),
      subjectID,
      subjectName: saIsPlaceholderName(rawName, subjectID) ? '' : rawName,
      totalMarks: Number(it.totalMarks ?? it.TotalMarks ?? 0) || 0,
    };
  });
  const classSubs = await fetchClassSubjectsLite(classID, sectionID);
  return saAttachDisplayNames(list, classSubs);
};

/* getsasubjectbybranchclassandterm kabhi exam par configure subjects ka
   subset deti hai, jabke marks getsauploadmarksbystudent par zyada subjects
   ke against padi hoti hain. Result card un missing subjects ko bhi dikhaye. */
export const mergeSaSubjectsWithStudentMarks = async ({ classID, sectionID, termID, examID, studentID }) => {
  const list = (await getMainExamSubjects({ classID, sectionID, termID, examID }).catch(() => [])) || [];
  const have = new Set(list.map(s => Number(s.subjectID)).filter(Boolean));
  const extra = [];
  if (studentID) {
    const examN = Number(examID);
    const termS = termID == null || termID === '' ? '' : String(termID);
    const classS = classID == null || classID === '' ? '' : String(classID);
    let page = 1;
    for (;;) {
      const j = await getJson(`/api/getsauploadmarksbystudent?StudentID=${encodeURIComponent(studentID)}&pageNo=${page}`).catch(() => null);
      const rows = Array.isArray(j) ? j : (j?.data || []);
      rows.forEach(rec => {
        if (examN && Number(rec.examID ?? rec.ExamID ?? 0) !== examN) return;
        if (termS && String(rec.termID ?? rec.TermID ?? '') !== termS) return;
        if (classS && String(rec.classID ?? rec.ClassID ?? '') !== classS) return;
        const sid = Number(rec.subjectID ?? rec.SubjectID ?? 0);
        if (!sid || have.has(sid)) return;
        have.add(sid);
        extra.push({
          id: Number(rec.id ?? rec.ID ?? 0),
          subjectID: sid,
          subjectName: String(rec.subjectName ?? rec.SubjectName ?? '').trim(),
          totalMarks: Number(rec.totalMarks ?? rec.TotalMarks ?? 0) || 0,
        });
      });
      const totalPages = Number(j?.totalPages || 1) || 1;
      if (!rows.length || page >= totalPages || page >= 30) break;
      page += 1;
    }
  }
  /* SIRF wahi subjects rakho jo is class ke against Launch Setup me map hain
     (subject-against-class). Warna woh purane/unmapped subjects — jinki kabhi
     marks upload ho gayi thi magar ab class se hataye ja chuke — bhi Single
     Assessment ke Total/Obtained me judte the. classSubs khaali ho (API fail)
     to filter mat lagao, warna card blank ho jayega. */
  const classSubs = await fetchClassSubjectsLite(classID, sectionID);
  const allowed = new Set((classSubs || [])
    .map(s => Number(s.subjectID ?? s.SubjectID ?? 0))
    .filter(Boolean));
  const scope = (arr) => (allowed.size ? arr.filter(s => allowed.has(Number(s.subjectID))) : arr);

  if (!extra.length) return scope(list);
  return saAttachDisplayNames(scope([...list, ...extra]), classSubs).map(s => ({
    ...s,
    subjectName: saIsPlaceholderName(s.subjectName, s.subjectID) ? `Subject ${s.subjectID}` : s.subjectName,
  }));
};

export const getStudentSubjectMark = ({ classID, sectionID, termID, examID, subjectID, studentID }) => {
  const params = new URLSearchParams({
    classID: String(classID), termID: String(termID ?? ''), ExamID: String(examID),
    SubjectID: String(subjectID), StudentID: String(studentID), sectionID: String(sectionID), pageNo: '1',
  });
  return getJson(`/api/getsauploadmarksbyclassandtermandexamandsubject?${params.toString()}`).then(j => {
    const rec = Array.isArray(j) ? j[0] : (j?.data?.[0] || null);
    return rec ? (Number(rec.obtainedMarks ?? rec.obtainMarks ?? rec.marks ?? rec.ObtainedMarks ?? 0) || 0) : 0;
  });
};

/* ── Student result card ── */
export const getStudentCard = ({ studentID, subExamIDs, classID, sectionID, mainExamID }) =>
  getJson(`/api/getcastudentexamresult?studentID=${studentID}&${examIdsQS(subExamIDs)}&branchID=${branchID()}&classID=${classID}&sectionID=${sectionID}&mainExamID=${mainExamID}`);

/* ── Remarks ── */
export const getRemarks = ({ classID, sectionID, examID, termID, studentID }) =>
  getJson(`/api/getremarksbystudentfiltersnew?branchID=${branchID()}&classID=${classID}&sectionID=${sectionID}&examID=${examID}&termID=${termID}&studentID=${studentID}&pageNo=1`);

/* payload: { action:'insert'|'update', id?, classID, sectionID, examID, termID, studentID, remarks } */
export const saveRemarks = (payload) =>
  postJson('/api/remarksforstudentcrudnew', { branchID: branchID(), ...payload });

/* ── Delete a class row ── */
export const deleteClassRow = ({ combinedResultID, gradeID, sectionID }) =>
  delJson(`/api/deletecombineassessment?combinedResultID=${combinedResultID}&gradeID=${gradeID}&sectionID=${sectionID}`);

/* ── Download a student result ── */
export const getDownloadLink = ({ subExamIDs, studentID }) =>
  getJson(`/api/getcaexaminationresultdownloadmobile?${examIdsQS(subExamIDs)}&studentID=${studentID}&branchID=${branchID()}`);

/* Map the list (get) response into the flat per-class-section rows the
   Combined Assessment UI renders. */
export function mapCombinedResults(apiList) {
  const out = [];
  (apiList || []).forEach(item => {
    const subExamNames = (item.subExams || []).map(s => s.examName);
    const subExamIDs   = (item.subExams || []).map(s => s.examID);
    const created = item.createdDate ? new Date(item.createdDate).toLocaleDateString('en-GB') : '';
    (item.classSections || []).forEach(cs => {
      out.push({
        id:               `${item.id}_${cs.classID}_${cs.sectionID}`,
        combinedResultID: item.id,
        name:             item.combinedResultName,
        cls:              cs.className,
        section:          cs.sectionName,
        classID:          cs.classID,
        sectionID:        cs.sectionID,
        mainExam:         item.mainExamName,
        mainExamID:       item.mainExamID,
        subExams:         subExamNames,
        subExamIDs,
        subExamMeta:      item.subExams || [],
        created,
        published:        !!cs.isPublished,
        studentCount:     cs.studentCount ?? 0,
        students:         [],   // loaded on row expand (Stage 3)
      });
    });
  });
  return out;
}
